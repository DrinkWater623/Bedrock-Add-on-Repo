import { world } from "@minecraft/server";

world.sendMessage("Hello World");
